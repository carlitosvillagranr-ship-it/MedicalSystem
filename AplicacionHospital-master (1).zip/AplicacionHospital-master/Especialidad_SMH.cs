﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSDPRN3_SMH_2302B1
{
    internal class Especialidad_SMH
    {
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
    }
}
