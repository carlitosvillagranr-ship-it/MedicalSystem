﻿namespace DSDPRN3_SMH_2302B1
{
    partial class CatalogoMedicos_SMH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCedula_SMH = new System.Windows.Forms.TextBox();
            this.txtMaterno_SMH = new System.Windows.Forms.TextBox();
            this.txtPaterno_SMH = new System.Windows.Forms.TextBox();
            this.txtNombre_SMH = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DGVmedico_SMH = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtID_SMH = new System.Windows.Forms.TextBox();
            this.txtCedulaN_SMH = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVmedico_SMH)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.txtCedula_SMH);
            this.groupBox1.Controls.Add(this.txtMaterno_SMH);
            this.groupBox1.Controls.Add(this.txtPaterno_SMH);
            this.groupBox1.Controls.Add(this.txtNombre_SMH);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(39, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(630, 200);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ingresar nuevo registro";
            // 
            // txtCedula_SMH
            // 
            this.txtCedula_SMH.Location = new System.Drawing.Point(198, 159);
            this.txtCedula_SMH.Name = "txtCedula_SMH";
            this.txtCedula_SMH.Size = new System.Drawing.Size(272, 20);
            this.txtCedula_SMH.TabIndex = 8;
            // 
            // txtMaterno_SMH
            // 
            this.txtMaterno_SMH.Location = new System.Drawing.Point(198, 123);
            this.txtMaterno_SMH.Name = "txtMaterno_SMH";
            this.txtMaterno_SMH.Size = new System.Drawing.Size(272, 20);
            this.txtMaterno_SMH.TabIndex = 7;
            // 
            // txtPaterno_SMH
            // 
            this.txtPaterno_SMH.Location = new System.Drawing.Point(198, 92);
            this.txtPaterno_SMH.Name = "txtPaterno_SMH";
            this.txtPaterno_SMH.Size = new System.Drawing.Size(272, 20);
            this.txtPaterno_SMH.TabIndex = 6;
            // 
            // txtNombre_SMH
            // 
            this.txtNombre_SMH.Location = new System.Drawing.Point(198, 55);
            this.txtNombre_SMH.Name = "txtNombre_SMH";
            this.txtNombre_SMH.Size = new System.Drawing.Size(272, 20);
            this.txtNombre_SMH.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(85, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Cédula Profesional";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Apellido Materno";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(87, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Apellido Paterno";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Chartreuse;
            this.button1.Location = new System.Drawing.Point(540, 171);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Guardar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.DGVmedico_SMH);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Location = new System.Drawing.Point(39, 246);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(630, 142);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Registros disponibles";
            // 
            // DGVmedico_SMH
            // 
            this.DGVmedico_SMH.BackgroundColor = System.Drawing.Color.LimeGreen;
            this.DGVmedico_SMH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVmedico_SMH.Location = new System.Drawing.Point(24, 26);
            this.DGVmedico_SMH.Name = "DGVmedico_SMH";
            this.DGVmedico_SMH.Size = new System.Drawing.Size(446, 93);
            this.DGVmedico_SMH.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Chartreuse;
            this.button3.Location = new System.Drawing.Point(543, 105);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "Eliminar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Chartreuse;
            this.button2.Location = new System.Drawing.Point(540, 39);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Actualizar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.groupBox3.Controls.Add(this.txtCedulaN_SMH);
            this.groupBox3.Controls.Add(this.txtID_SMH);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Location = new System.Drawing.Point(42, 413);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(627, 100);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Modificar cédula profesional";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Chartreuse;
            this.button4.Location = new System.Drawing.Point(540, 53);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 0;
            this.button4.Text = "Modificar";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Ingresa el ID del médico";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(37, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Registra la nueva cédula";
            // 
            // txtID_SMH
            // 
            this.txtID_SMH.Location = new System.Drawing.Point(170, 26);
            this.txtID_SMH.Name = "txtID_SMH";
            this.txtID_SMH.Size = new System.Drawing.Size(100, 20);
            this.txtID_SMH.TabIndex = 3;
            // 
            // txtCedulaN_SMH
            // 
            this.txtCedulaN_SMH.Location = new System.Drawing.Point(168, 58);
            this.txtCedulaN_SMH.Name = "txtCedulaN_SMH";
            this.txtCedulaN_SMH.Size = new System.Drawing.Size(299, 20);
            this.txtCedulaN_SMH.TabIndex = 4;
            // 
            // CatalogoMedicos_SMH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DSDPRN3_SMH_2302B1.Properties.Resources.IMG_Medico;
            this.ClientSize = new System.Drawing.Size(704, 527);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "CatalogoMedicos_SMH";
            this.Text = "CatalogoMedicos_SMH";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVmedico_SMH)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtCedula_SMH;
        private System.Windows.Forms.TextBox txtMaterno_SMH;
        private System.Windows.Forms.TextBox txtPaterno_SMH;
        private System.Windows.Forms.TextBox txtNombre_SMH;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView DGVmedico_SMH;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox txtCedulaN_SMH;
        private System.Windows.Forms.TextBox txtID_SMH;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
    }
}