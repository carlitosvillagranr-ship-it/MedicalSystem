﻿namespace DSDPRN3_SMH_2302B1
{
    partial class CatalogoPacientes
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBox_SMH = new System.Windows.Forms.GroupBox();
            this.RdHombre_SMH = new System.Windows.Forms.RadioButton();
            this.RdMujer_SMH = new System.Windows.Forms.RadioButton();
            this.CbEdoCivil_SMH = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtEdad_SMH = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCorreo_SMH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCelular_SMH = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTelefono_SMH = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNombre_SMH = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDireccion_SMH = new System.Windows.Forms.TextBox();
            this.txtMaterno_SMH = new System.Windows.Forms.TextBox();
            this.txtPaterno_SMH = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.DGVpacientes_SMH = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtID_SMH = new System.Windows.Forms.TextBox();
            this.txtCelularN_SMH = new System.Windows.Forms.TextBox();
            this.txtDomicilioN_SMH = new System.Windows.Forms.TextBox();
            this.txtTelefonoN_SMH = new System.Windows.Forms.TextBox();
            this.txtCorreoN_SMH = new System.Windows.Forms.TextBox();
            this.GroupBox_SMH.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVpacientes_SMH)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox_SMH
            // 
            this.GroupBox_SMH.BackColor = System.Drawing.Color.DarkTurquoise;
            this.GroupBox_SMH.Controls.Add(this.RdHombre_SMH);
            this.GroupBox_SMH.Controls.Add(this.RdMujer_SMH);
            this.GroupBox_SMH.Location = new System.Drawing.Point(497, 33);
            this.GroupBox_SMH.Name = "GroupBox_SMH";
            this.GroupBox_SMH.Size = new System.Drawing.Size(220, 62);
            this.GroupBox_SMH.TabIndex = 1;
            this.GroupBox_SMH.TabStop = false;
            this.GroupBox_SMH.Text = "Sexo";
            // 
            // RdHombre_SMH
            // 
            this.RdHombre_SMH.AutoSize = true;
            this.RdHombre_SMH.Location = new System.Drawing.Point(38, 36);
            this.RdHombre_SMH.Name = "RdHombre_SMH";
            this.RdHombre_SMH.Size = new System.Drawing.Size(62, 17);
            this.RdHombre_SMH.TabIndex = 3;
            this.RdHombre_SMH.TabStop = true;
            this.RdHombre_SMH.Text = "Hombre";
            this.RdHombre_SMH.UseVisualStyleBackColor = true;
            // 
            // RdMujer_SMH
            // 
            this.RdMujer_SMH.AutoSize = true;
            this.RdMujer_SMH.Location = new System.Drawing.Point(40, 13);
            this.RdMujer_SMH.Name = "RdMujer_SMH";
            this.RdMujer_SMH.Size = new System.Drawing.Size(51, 17);
            this.RdMujer_SMH.TabIndex = 2;
            this.RdMujer_SMH.TabStop = true;
            this.RdMujer_SMH.Text = "Mujer";
            this.RdMujer_SMH.UseVisualStyleBackColor = true;
            // 
            // CbEdoCivil_SMH
            // 
            this.CbEdoCivil_SMH.FormattingEnabled = true;
            this.CbEdoCivil_SMH.Items.AddRange(new object[] {
            "Soltero",
            "Casado",
            "Divorciado",
            "Viudo",
            "Concubinato"});
            this.CbEdoCivil_SMH.Location = new System.Drawing.Point(587, 104);
            this.CbEdoCivil_SMH.Name = "CbEdoCivil_SMH";
            this.CbEdoCivil_SMH.Size = new System.Drawing.Size(124, 21);
            this.CbEdoCivil_SMH.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtEdad_SMH);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCorreo_SMH);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtCelular_SMH);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtTelefono_SMH);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtNombre_SMH);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtDireccion_SMH);
            this.groupBox1.Controls.Add(this.txtMaterno_SMH);
            this.groupBox1.Controls.Add(this.txtPaterno_SMH);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.GroupBox_SMH);
            this.groupBox1.Controls.Add(this.CbEdoCivil_SMH);
            this.groupBox1.Location = new System.Drawing.Point(34, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(723, 242);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ingresar nuevo registro";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Teal;
            this.button4.Location = new System.Drawing.Point(639, 44);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Modificar";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button1.Location = new System.Drawing.Point(636, 205);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Guardar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtEdad_SMH
            // 
            this.txtEdad_SMH.Location = new System.Drawing.Point(587, 147);
            this.txtEdad_SMH.Name = "txtEdad_SMH";
            this.txtEdad_SMH.Size = new System.Drawing.Size(124, 20);
            this.txtEdad_SMH.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(494, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Edad";
            // 
            // txtCorreo_SMH
            // 
            this.txtCorreo_SMH.Location = new System.Drawing.Point(145, 172);
            this.txtCorreo_SMH.Name = "txtCorreo_SMH";
            this.txtCorreo_SMH.Size = new System.Drawing.Size(332, 20);
            this.txtCorreo_SMH.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Correo electrónico";
            // 
            // txtCelular_SMH
            // 
            this.txtCelular_SMH.Location = new System.Drawing.Point(344, 208);
            this.txtCelular_SMH.Name = "txtCelular_SMH";
            this.txtCelular_SMH.Size = new System.Drawing.Size(134, 20);
            this.txtCelular_SMH.TabIndex = 16;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(299, 215);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Celular";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(494, 107);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Estado Civil";
            // 
            // txtTelefono_SMH
            // 
            this.txtTelefono_SMH.Location = new System.Drawing.Point(146, 208);
            this.txtTelefono_SMH.Name = "txtTelefono_SMH";
            this.txtTelefono_SMH.Size = new System.Drawing.Size(136, 20);
            this.txtTelefono_SMH.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Teléfono";
            // 
            // txtNombre_SMH
            // 
            this.txtNombre_SMH.Location = new System.Drawing.Point(145, 33);
            this.txtNombre_SMH.Name = "txtNombre_SMH";
            this.txtNombre_SMH.Size = new System.Drawing.Size(332, 20);
            this.txtNombre_SMH.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(37, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Dirección";
            // 
            // txtDireccion_SMH
            // 
            this.txtDireccion_SMH.Location = new System.Drawing.Point(145, 140);
            this.txtDireccion_SMH.Name = "txtDireccion_SMH";
            this.txtDireccion_SMH.Size = new System.Drawing.Size(332, 20);
            this.txtDireccion_SMH.TabIndex = 9;
            // 
            // txtMaterno_SMH
            // 
            this.txtMaterno_SMH.Location = new System.Drawing.Point(145, 104);
            this.txtMaterno_SMH.Name = "txtMaterno_SMH";
            this.txtMaterno_SMH.Size = new System.Drawing.Size(332, 20);
            this.txtMaterno_SMH.TabIndex = 8;
            // 
            // txtPaterno_SMH
            // 
            this.txtPaterno_SMH.Location = new System.Drawing.Point(145, 65);
            this.txtPaterno_SMH.Name = "txtPaterno_SMH";
            this.txtPaterno_SMH.Size = new System.Drawing.Size(332, 20);
            this.txtPaterno_SMH.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(34, 107);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Apellido Materno";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(84, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Apellido Paterno";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nombre(s)";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.DGVpacientes_SMH);
            this.groupBox2.Location = new System.Drawing.Point(34, 260);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(723, 170);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Registros disponibles";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button3.Location = new System.Drawing.Point(636, 133);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Eliminar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button2.Location = new System.Drawing.Point(636, 89);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Actualizar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // DGVpacientes_SMH
            // 
            this.DGVpacientes_SMH.BackgroundColor = System.Drawing.Color.DarkTurquoise;
            this.DGVpacientes_SMH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVpacientes_SMH.Location = new System.Drawing.Point(21, 32);
            this.DGVpacientes_SMH.Name = "DGVpacientes_SMH";
            this.DGVpacientes_SMH.Size = new System.Drawing.Size(592, 124);
            this.DGVpacientes_SMH.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.MediumTurquoise;
            this.groupBox3.Controls.Add(this.txtCorreoN_SMH);
            this.groupBox3.Controls.Add(this.txtTelefonoN_SMH);
            this.groupBox3.Controls.Add(this.txtDomicilioN_SMH);
            this.groupBox3.Controls.Add(this.txtCelularN_SMH);
            this.groupBox3.Controls.Add(this.txtID_SMH);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Location = new System.Drawing.Point(31, 436);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(726, 107);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Modificar domicilio y contacto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Ingresa el ID del paciente";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ingresa el domicilio";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(350, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Ingresa el correo";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(342, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Ingresa el teléfono";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(25, 47);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 13);
            this.label14.TabIndex = 8;
            this.label14.Text = "Ingresa el celular";
            // 
            // txtID_SMH
            // 
            this.txtID_SMH.Location = new System.Drawing.Point(159, 13);
            this.txtID_SMH.Name = "txtID_SMH";
            this.txtID_SMH.Size = new System.Drawing.Size(125, 20);
            this.txtID_SMH.TabIndex = 9;
            // 
            // txtCelularN_SMH
            // 
            this.txtCelularN_SMH.Location = new System.Drawing.Point(159, 44);
            this.txtCelularN_SMH.Name = "txtCelularN_SMH";
            this.txtCelularN_SMH.Size = new System.Drawing.Size(125, 20);
            this.txtCelularN_SMH.TabIndex = 10;
            // 
            // txtDomicilioN_SMH
            // 
            this.txtDomicilioN_SMH.Location = new System.Drawing.Point(159, 79);
            this.txtDomicilioN_SMH.Name = "txtDomicilioN_SMH";
            this.txtDomicilioN_SMH.Size = new System.Drawing.Size(413, 20);
            this.txtDomicilioN_SMH.TabIndex = 11;
            // 
            // txtTelefonoN_SMH
            // 
            this.txtTelefonoN_SMH.Location = new System.Drawing.Point(447, 21);
            this.txtTelefonoN_SMH.Name = "txtTelefonoN_SMH";
            this.txtTelefonoN_SMH.Size = new System.Drawing.Size(125, 20);
            this.txtTelefonoN_SMH.TabIndex = 12;
            // 
            // txtCorreoN_SMH
            // 
            this.txtCorreoN_SMH.Location = new System.Drawing.Point(447, 52);
            this.txtCorreoN_SMH.Name = "txtCorreoN_SMH";
            this.txtCorreoN_SMH.Size = new System.Drawing.Size(125, 20);
            this.txtCorreoN_SMH.TabIndex = 13;
            // 
            // CatalogoPacientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = global::DSDPRN3_SMH_2302B1.Properties.Resources.patron2;
            this.ClientSize = new System.Drawing.Size(778, 556);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "CatalogoPacientes";
            this.Text = "REGISTRO DE PACIENTE";
            this.GroupBox_SMH.ResumeLayout(false);
            this.GroupBox_SMH.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVpacientes_SMH)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox GroupBox_SMH;
        private System.Windows.Forms.RadioButton RdMujer_SMH;
        private System.Windows.Forms.RadioButton RdHombre_SMH;
        private System.Windows.Forms.ComboBox CbEdoCivil_SMH;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDireccion_SMH;
        private System.Windows.Forms.TextBox txtMaterno_SMH;
        private System.Windows.Forms.TextBox txtPaterno_SMH;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTelefono_SMH;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNombre_SMH;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtEdad_SMH;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCorreo_SMH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCelular_SMH;
        private System.Windows.Forms.DataGridView DGVpacientes_SMH;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCorreoN_SMH;
        private System.Windows.Forms.TextBox txtTelefonoN_SMH;
        private System.Windows.Forms.TextBox txtDomicilioN_SMH;
        private System.Windows.Forms.TextBox txtCelularN_SMH;
        private System.Windows.Forms.TextBox txtID_SMH;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
    }
}

