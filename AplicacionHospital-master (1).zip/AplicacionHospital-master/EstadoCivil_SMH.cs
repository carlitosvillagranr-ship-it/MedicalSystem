﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSDPRN3_SMH_2302B1
{
    internal class EstadoCivil_SMH
    {
        
        public string EstadoCivil_nombre { get; set; }

    }
}
